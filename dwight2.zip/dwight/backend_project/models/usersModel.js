import mongoose from 'mongoose';

const userSchema = mongoose.Schema({
    firstName: String,
    lastName: String,
    userName: String,
    email: String,
    password: String,
    isAdmin: {
        type: Boolean,
        default: false
    }
});

export default mongoose.model('User', userSchema);