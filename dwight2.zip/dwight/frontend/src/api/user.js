export const getUsers = async () => {
  const response = await fetch("http://localhost:5000/api/users");
  return response.json();
};