import React, { useEffect, useState } from "react";
import { getUsers } from "../api";

export default function GetUsers() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const data = await getUsers();
      setUsers(data);
    };

    fetchData();
  }, []);

  return (
    <div>
      <h3>List of Users</h3>

      {users.length === 0 ? (
        <p>No users found</p>
      ) : (
        users.map((user, index) => (
          <div key={user._id || index}>
            <p>{user.firstName} {user.lastName}</p>
            <p>Firstname: {user.firstName}</p>
            <p>Lastname: {user.lastName}</p>
            <p>Username: {user.userName}</p>
          </div>
        ))
      )}
    </div>
  );
}