export const getUsers = async () => {
  try {
    const res = await fetch("http://localhost:5000/api/users");

    if (!res.ok) {
      throw new Error("Failed to fetch users");
    }

    return await res.json();
  } catch (error) {
    console.error("Error fetching users:", error);
    return [];
  }
};